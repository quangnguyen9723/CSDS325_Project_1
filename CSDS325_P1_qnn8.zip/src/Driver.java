import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.ListIterator;

public class Driver {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
