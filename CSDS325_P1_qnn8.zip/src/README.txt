If not at src folder, use the command 'cd src'
After that, compile all java files by using command 'java *'

To use the program, start the server first by using command 'java ChatServer 80'. You are free to use any other number instead of 80 for port.
To start the client, use command 'java ChatClient <hostname> <port number>'. You have to determine the hostname of server and the port number that the server program is running.